
    import '../../public/assets/vendor/libs/jquery/jquery.js'
    import '../../public/assets/vendor/libs/popper/popper.js'


    import '../../public/assets/vendor/js/bootstrap.js'
    import '../../public/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js'
    import '../../public/assets/vendor/libs/hammer/hammer.js'
    import '../../public/assets/vendor/libs/i18n/i18n.js'
    import '../../public/assets/vendor/libs/typeahead-js/typeahead.js'

    import '../../public/assets/vendor/js/menu.js'

    import '../../public/assets/vendor/libs/apex-charts/apexcharts.js'
    import '../../public/assets/vendor/libs/select2/select2.js'
    import '../../public/assets/vendor/libs/bootstrap-select/bootstrap-select.js'
    import '../../public/assets/vendor/libs/moment/moment.js'
    import '../../public/assets/vendor/libs/flatpickr/flatpickr.js'
    import '../../public/assets/vendor/libs/typeahead-js/typeahead.js'
    import '../../public/assets/vendor/libs/tagify/tagify.js'
    import '../../public/assets/vendor/libs/formvalidation/dist/js/FormValidation.min.js'
    import '../../public/assets/vendor/libs/formvalidation/dist/js/plugins/Bootstrap5.min.js'
    import '../../public/assets/vendor/libs/formvalidation/dist/js/plugins/AutoFocus.min.js'



    import '../../public/assets/vendor/libs/datatables/jquery.dataTables.js'
    import '../../public/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js'
    import '../../public/assets/vendor/libs/datatables-responsive/datatables.responsive.js'
    import '../../public/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.js'
    import '../../public/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.js'


    import '../../public/assets/js/main.js'


    import '../../public/assets/js/dashboards-analytics.js'
    import '../../public/assets/js/extended-ui-perfect-scrollbar.js'
    import '../../public/assets/js/form-validation.js'
    import '../../public/assets/vendor/libs/sweetalert2/sweetalert2.js'
    import '../../public/assets/js/extended-ui-sweetalert2.js'

