// import {createRouter ,createWebHistory} from "vue-router";
//
// //admin
//
//
// const router = createRouter({
//     history : createWebHistory(),
//
//     routes :[
//         {
//
//         }
//
//     ],
// });
//
// export default router;
