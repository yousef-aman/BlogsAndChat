<script setup>


</script>

<template>

hello im about vue

</template>
