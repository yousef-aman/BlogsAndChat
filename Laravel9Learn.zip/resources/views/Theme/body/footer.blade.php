<footer class="content-footer footer bg-footer-theme">
    <div class="container-fluid d-flex flex-column flex-md-row flex-wrap justify-content-between py-2">
        <div class="mb-2 mb-md-0">
            ©
{{--            <script>--}}
{{--                document.write(new Date().getFullYear());--}}
{{--            </script>--}}
            , made with ❤️ by
            <a  target="_blank" class="footer-link fw-semibold">Yousef</a>
        </div>

    </div>
</footer>
